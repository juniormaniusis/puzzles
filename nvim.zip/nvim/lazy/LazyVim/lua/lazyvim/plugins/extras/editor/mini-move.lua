return {
  {
    "nvim-mini/mini.move",
    event = "VeryLazy",
    opts = {},
  },
}
