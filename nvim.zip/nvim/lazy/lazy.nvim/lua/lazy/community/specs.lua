---@type table<string, LazySpec>
return {
  ["plenary.nvim"] = {
    "nvim-lua/plenary.nvim",
    lazy = true,
  },
}
